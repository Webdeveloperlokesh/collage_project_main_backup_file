Mera GitHub account "Webdeveloperlokesh" is name se hai.

1 - Aapko mere GitHub account me repository hai jiska name and link dono hai isme - https://github.com/Webdeveloperlokesh/Collage_project-login-and-logout-page-with-php-database

2 - Aapko meri repository ka code download karna hai.
3 - Then aapko jana hai 'This Pc' me usme 'windows c' me jana hai xampp ka folder me jana hai fir htdocs ke folder me jana hai then htdocs ke folder me ye folder aapko paste karne hai.
4 - fir aapko database banana hai 'login' name se usme aapko table create karna hai uska name 'users' rakhna hai.
5 - Fir aapko xampp server ko start karna hai or browser me aa kr search karna hai.
7 - or last me run karke dekhna hai. 
		
						|| Thanks You ||   